// Получаем элементы формы и списка привычек
const habitForm = document.getElementById('habit-form');
const habitInput = document.getElementById('habit-input');
const habitList = document.getElementById('habit-list');

// Обработчик отправки формы
habitForm.addEventListener('submit', function(event) {
  event.preventDefault();

  // Получаем значение из поля ввода
  const habitName = habitInput.value.trim();

  if (habitName !== '') {
    // Создаем новый элемент списка привычек
    const habitItem = document.createElement('li');
    habitItem.classList.add('habit-item');

    // Создаем элемент для имени привычки
    const habitNameElement = document.createElement('span');
    habitNameElement.classList.add('habit-name');
    habitNameElement.textContent = habitName;

    // Создаем кнопку для удаления привычки
    const deleteButton = document.createElement('button');
    deleteButton.classList.add('delete-button');
    deleteButton.textContent = 'Delete';

    // Добавляем элементы в элемент списка привычек
    habitItem.appendChild(habitNameElement);
    habitItem.appendChild(deleteButton);

    // Добавляем элемент списка привычек в список
    habitList.appendChild(habitItem);

    // Очищаем поле ввода
    habitInput.value = '';
  }
});

// Обработчик удаления привычки
habitList.addEventListener('click', function(event) {
  if (event.target.classList.contains('delete-button')) {
    const habitItem = event.target.closest('.habit-item');
    habitItem.remove();
  }
});

