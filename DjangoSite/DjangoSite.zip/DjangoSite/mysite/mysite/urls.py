from django.shortcuts import render
from django.contrib import admin
from django.urls import path
from myapp.views import home, calendar

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', home, name='home'),
    path('calendar/', calendar, name='calendar'),
]
